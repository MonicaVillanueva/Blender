Installation:

1. Start Blender. Open User Preferences, the addons tab 
2. Click "install from file" and point Blender at the downloaded zip
3. Activate the sculpt tools addons from user preferences
3. Save user preferences if you want to have it on at startup.